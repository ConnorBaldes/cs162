
Name: Connor Baldes

 
Description: This is my assignment 5 for CS 162. Inlcuded is a make file, Linked list node hpp file, 

Linked list hpp file, and driver file. the linked list node hpp file contains the definition of my linked

list node class and all of its corresponding member functions. the linked list hpp contains my linked 

list class and all of the functions associated with it. The driver file has my main function along with two

functions that check for signed and unsinged intergers. I seperated these files because I did not believe 

it would be benificial in any way for them to be attacked to a certain class. The program runs as it 

should(To my best understanding). The program first asks the user wether they would like to input signed 

or unsigned integers(*extra credit), then it asks for the first number and if you would like to entere 

another number it will continue this until you choose to stop entering numbers. The program then gives you

the option to sort the numbers in an ascending or descending order, both use the merge sort algorythm to 

sort the numbers. The program will then check for prime numbers if you chose unsiged integers the size of the 

prime numbers can be much larger. Negative numbers are always treated as non prime. the classes and pointers 

are then deleted and you are asked if you want to go again and you can re start the entire process.


Important notes:

-Used template classes and hpp files 

-Make file only compiles driver file, I dont know if this is correct when using  
 
 hpp files but including them in the makefile compilation caused and error.

-I think it works correcty:)